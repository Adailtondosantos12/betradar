BetRadar - Pacote pronto para deploy

Estrutura do pacote:
- backend/  -> Node.js backend (Express)
- frontend/ -> Next.js web app
- mobile/   -> Expo mobile app (preconfigurado para usar backend)

Variáveis de ambiente já pré-configuradas (exemplo):
- backend/.env (substitua host/credentials):
  DATABASE_URL=postgresql://betradar_user:change_this_password@your-render-db-host:5432/betradar_db
  JWT_SECRET=a8f624992a7ea69f3c1651405f4f56afd64004845f235a1bba6d7eac31f13fbb
  ODDS_API_KEY=insira_sua_oddsapi_key
  API_FOOTBALL_KEY=insira_sua_api_football_key

- frontend/.env.local:
  NEXT_PUBLIC_API_URL=https://betradar-backend.onrender.com/api

Passos de deploy recomendados:
1) Criar um serviço PostgreSQL no Render (ou Supabase) e obter a connection string. Substitua DATABASE_URL em backend/.env.
2) Subir backend/ para Render (Web Service) com Start Command: npm start . Defina as mesmas variáveis no painel do Render.
3) Subir frontend/ para Vercel. Certifique-se de definir NEXT_PUBLIC_API_URL no painel do Vercel (ou manter o .env.local).
4) Para mobile, use Expo EAS build apontando para a API pública do backend.

Observações de segurança:
- Troque as senhas de exemplo antes de colocar em produção.
- Guarde a chave JWT em local seguro e não a commit no repositório público.
