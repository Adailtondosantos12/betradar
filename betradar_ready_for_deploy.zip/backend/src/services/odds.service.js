const axios = require('axios');

const ODDS_API_KEY = process.env.ODDS_API_KEY;

async function fetchOddsGames(league) {
  const sportKey = league === 'all' ? 'soccer' : league;
  const url = `https://api.the-odds-api.com/v4/sports/${sportKey}/odds`;
  const resp = await axios.get(url, {
    params: {
      apiKey: ODDS_API_KEY,
      regions: 'eu,us',
      markets: 'h2h,spreads,totals'
    },
    timeout: 8000
  });
  return resp.data;
}

async function fetchOddsByGame(gameId) {
  const url = `https://api.the-odds-api.com/v4/events/${gameId}/odds`;
  const resp = await axios.get(url, { params: { apiKey: ODDS_API_KEY } });
  return resp.data;
}

module.exports = { fetchOddsGames, fetchOddsByGame };
