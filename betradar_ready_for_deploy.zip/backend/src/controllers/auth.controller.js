const db = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

async function signup(req, res) {
  try {
    const { email, password, name } = req.body;
    if (!email || !password) return res.status(400).json({ success:false, message: 'Email e senha são obrigatórios' });

    const hash = await bcrypt.hash(password, 10);
    const insert = await db.query(
      'INSERT INTO users(email, password_hash, name) VALUES($1, $2, $3) RETURNING id, email, name',
      [email, hash, name || null]
    );

    const user = insert.rows[0];
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ success:true, user, token });
  } catch (err) {
    console.error(err);
    if (err.code === '23505') return res.status(400).json({ success:false, message: 'Email já cadastrado' });
    res.status(500).json({ success:false, message: 'Erro no servidor' });
  }
}

async function login(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ success:false, message: 'Email e senha são obrigatórios' });

    const result = await db.query('SELECT id, email, password_hash, name FROM users WHERE email=$1', [email]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ success:false, message: 'Credenciais inválidas' });

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.status(401).json({ success:false, message: 'Credenciais inválidas' });

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ success:true, user: { id: user.id, email: user.email, name: user.name }, token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success:false, message: 'Erro no servidor' });
  }
}

module.exports = { signup, login };
