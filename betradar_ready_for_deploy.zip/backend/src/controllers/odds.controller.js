const oddsService = require('../services/odds.service');

async function listGamesWithOdds(req, res) {
  try {
    const league = req.query.league || 'all';
    const data = await oddsService.fetchOddsGames(league);
    res.json({ success:true, data });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success:false, message: 'Erro ao buscar odds' });
  }
}

async function getOddsByGame(req, res) {
  try {
    const gameId = req.params.id;
    const data = await oddsService.fetchOddsByGame(gameId);
    res.json({ success:true, data });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success:false, message: 'Erro ao buscar odds do jogo' });
  }
}

module.exports = { listGamesWithOdds, getOddsByGame };
