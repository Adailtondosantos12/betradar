const express = require('express');
const router = express.Router();

const authCtrl = require('./controllers/auth.controller');
const oddsCtrl = require('./controllers/odds.controller');

router.post('/auth/signup', authCtrl.signup);
router.post('/auth/login', authCtrl.login);
router.get('/odds/games', oddsCtrl.listGamesWithOdds);
router.get('/odds/game/:id', oddsCtrl.getOddsByGame);

module.exports = router;
