BetRadar - Backend (Pronto para Deploy)

Observações:
- Substitua a string CONNECTION em .env (DATABASE_URL) pela URL do banco PostgreSQL do Render/Supabase.
- As credenciais usadas em .env são de exemplo: ajuste user/password/host antes de ativar.
- Certifique-se de configurar as variáveis de ambiente no painel do Render (ou outro provedor) com os mesmos valores do .env.

Comandos (local):
npm install
npm run dev

Deploy no Render (resumo):
- New -> Web Service -> Deploy from Git or Manual Upload
- Runtime: Node 18+
- Start Command: npm start
- Defina variáveis de ambiente no painel do Render (DATABASE_URL, JWT_SECRET, ODDS_API_KEY, API_FOOTBALL_KEY).
