BetRadar Web (Next.js) - Pronto para Deploy

Instruções rápidas:
- npm install
- NEXT_PUBLIC_API_URL já apontado para https://betradar-backend.onrender.com/api
- npm run build
- Deploy no Vercel (ou serviço semelhante)
