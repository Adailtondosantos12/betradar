import useSWR from 'swr'
const fetcher = (url) => fetch(url).then(r=>r.json())

export default function Home() {
  const { data, error } = useSWR(process.env.NEXT_PUBLIC_API_URL + '/odds/games?league=all', fetcher)
  return (
    <div style={{maxWidth:960, margin:'24px auto', padding:16}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>BetRadar</h1>
        <div>Melhores estatísticas. Melhores odds.</div>
      </header>
      <main style={{marginTop:20}}>
        {!data && <div style={{padding:12, borderRadius:12, background:'#f3f4f6'}}>Carregando jogos...</div>}
        {error && <div style={{padding:12, borderRadius:12, background:'#fee2e2'}}>Erro ao carregar: {error.message}</div>}
        {data && data.data && data.data.length===0 && <div style={{padding:12, borderRadius:12, background:'#fff'}}>Nenhum jogo encontrado</div>}
        {data && data.data && data.data.map((game)=> (
          <div key={game.id} style={{padding:12, borderRadius:12, background:'#fff', marginBottom:12, boxShadow:'0 1px 3px rgba(0,0,0,0.06)'}}>
            <div style={{display:'flex', justifyContent:'space-between'}}>
              <div><strong>{game.home_team}</strong> x <strong>{game.away_team}</strong></div>
              <div>{game.commence_time}</div>
            </div>
            <div style={{marginTop:8}}>
              {game.bookmakers && game.bookmakers.slice(0,4).map((bm)=> (
                <div key={bm.key} style={{display:'inline-block', marginRight:8}}>
                  <small>{bm.title}</small><br/>
                  <small>{bm.markets && bm.markets[0] ? JSON.stringify(bm.markets[0].outcomes) : '—'}</small>
                </div>
              ))}
            </div>
          </div>
        ))}
      </main>
    </div>
  )
}
