BetRadar Mobile (Expo) - Pronto para Build
- API_URL já apontado para https://betradar-backend.onrender.com/api
- npm install
- eas build -p android (ou ios)
