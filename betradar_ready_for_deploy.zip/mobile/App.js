import React,{useEffect,useState} from 'react';
import { SafeAreaView, Text, FlatList, View, ActivityIndicator } from 'react-native';
import axios from 'axios';
const API_URL = 'https://betradar-backend.onrender.com/api';

export default function App(){
  const [games, setGames] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(()=>{ (async ()=>{ try{ const r = await axios.get(API_URL + '/odds/games?league=all'); setGames(r.data.data || r.data); }catch(e){ console.error(e); } setLoading(false); })(); },[]);
  if(loading) return <SafeAreaView style={{flex:1, justifyContent:'center',alignItems:'center'}}><ActivityIndicator/></SafeAreaView>
  return (
    <SafeAreaView style={{flex:1, padding:12}}>
      <Text style={{fontSize:22,fontWeight:'700'}}>BetRadar</Text>
      <Text style={{marginBottom:10}}>Melhores estatísticas. Melhores odds.</Text>
      <FlatList data={games} keyExtractor={(item)=>String(item.id)} renderItem={({item})=>(
        <View style={{padding:12, borderRadius:10, backgroundColor:'#f3f4f6', marginBottom:10}}>
          <Text style={{fontWeight:'700'}}>{item.home_team} x {item.away_team}</Text>
          <Text style={{marginTop:6}}>{item.commence_time}</Text>
        </View>
      )} />
    </SafeAreaView>
  )
}
